package sample

import javafx.event.Event
import javafx.fxml.FXML
import javafx.scene.control.Button
import javafx.scene.control.TextArea
import javafx.scene.control.TextField

class Controller {
    @FXML
    lateinit var ques: TextArea

    @FXML
    lateinit var opt1: TextField

    @FXML
    lateinit var opt2: TextField

    @FXML
    lateinit var opt3: TextField

    @FXML
    lateinit var opt4: TextField

    @FXML
    lateinit var one: Button

    @FXML
    lateinit var two: Button

    @FXML
    lateinit var three: Button

    @FXML
    lateinit var four: Button

    @FXML
    lateinit var rslt: TextArea

    @FXML
    var ch = 1

        fun result(e:Event) {


            if (ch==1) {
                ques.text = "What is the capital of Austria?"
                opt1.text = "Vianna"
                opt2.text = "canbera"
                opt3.text = "perth"
                opt4.text = "paris"
                when(e.source){
                    one->{
                          ch=2
                        rslt.text="attempt"
                    }
                    two->rslt.text="Soory!!wrong answer"
                    three->rslt.text="Soory!!wrong answer"
                    four->rslt.text="Soory!!wrong answer"
                    else->{
                        rslt.text="attempt the first question!!"
                    }

                }

            }
            if(ch==2){
                ques.text = "which country won the cricket world cup in 1987?"
                opt1.text = "West indies"
                opt2.text = "england"
                opt3.text = "pakistan"
                opt4.text = "australia"
                when(e.source){
                    four->{ ch=3

                    }
                    else->{
                        rslt.text="well!! try next one"
                    }


                }
            }
            if(ch==3){
                ques.text = "Which country won the fifa wc2014?"
                opt1.text = "Spain"
                opt2.text = "Germany"
                opt3.text = "Italy"
                opt4.text = "France"
                when(e.source){
                    two->{
                        ch=4
                        rslt.text=""
                    }

                    else->{
                        rslt.text="this is just a starting"
                    }

                }
            }
            if(ch==4){
            ques.text = "What is the currency of russia?"
            opt1.text = "Dollar"
            opt2.text = "rouble"
            opt3.text = "Euro"
            opt4.text = "yen"
            when(e.source){
                two->{
                    ch=5

                    rslt.text=""
                }

                else->{
                    rslt.text="nyc one right??!!"
                }

            }
        }
            if(ch==5){
                ques.text = "Which country has no river?"
                opt1.text = "Saudi Arab"
                opt2.text = "UAE"
                opt3.text = "Egypt"
                opt4.text = "taiwan"
                when(e.source){
                    one->{
                        ch=6
                        rslt.text=""
                    }

                    else->{
                        rslt.text="keep going"
                    }

                }
            }
            if(ch==6){
                ques.text = "When was the first Khalsa Panth formed??"
                opt1.text = "1677"
                opt2.text = "1699"
                opt3.text = "1707"
                opt4.text = "1697"
                when(e.source){
                    two->{
                        ch=7
                        rslt.text=""
                    }

                    else->{
                        rslt.text="attempt the  question!!"
                    }

                }
            }
            if(ch==7){
                ques.text = "Who is the designer of PUBG?"
                opt1.text = "Mitchellie marsh"
                opt2.text = "Kim chang hang"
                opt3.text = "Brendon Greene"
                opt4.text = "Jang Tae"
                when(e.source){
                    three->{
                        ch=8
                        rslt.text=""
                    }

                    else->{
                        rslt.text="attempt the  question!!"
                    }

                }
            }
            if(ch==8){
                ques.text = "Developer of Whatsapp is --"
                opt1.text = "Brian Acton"
                opt2.text = "Larry Page"
                opt3.text = "Ron Wiesley"
                opt4.text = "Kristen King"
                when(e.source){
                    one->{
                        ch=9
                        rslt.text=""
                    }

                    else->{
                        rslt.text="attempt the  question!!"
                    }

                }
            }
            if(ch==9){
                ques.text = "What is the capital of Egypt??"
                opt1.text = "Tripoli"
                opt2.text = "Cairo"
                opt3.text = "Pritoria"
                opt4.text = "Amesterdam"
                when(e.source){
                    two->{
                        ch=10
                        rslt.text=""
                    }

                    else->{
                        rslt.text="attempt the  question!!"
                    }

                }
            }
            if(ch==10)
            {
                ques.text = "Silicon city is__"
                opt1.text = "chennai"
                opt2.text = "Mumbai"
                opt3.text = "Hyderabad"
                opt4.text = "Banglore"
                when(e.source){
                    four->{
                        rslt.text="YOU made it congrats!!"
                        }

                    else->{
                        rslt.text=""
                    }
                }
            }

        }


    }
